#!/usr/bin/env python3
"""Verify an OCSF event chain carrying the attestation object from PR #1661.

Standalone, offline, stdlib-only for the hash chain. If the `cryptography`
package is installed and a public key PEM is present, also verifies the
ECDSA signature on every event.

Usage:
    python3 verify_ocsf_example.py ocsf_example_chain.json
    python3 verify_ocsf_example.py ocsf_example_chain_TAMPERED.json

Verification per event:
  1. Rebuild the canonical bytes: JCS of the event record EXCLUDING
     attestation.entry_hash and attestation.signature (declared by
     digital_signature.serialization_id = 1 / JCS, per #1662).
  2. SHA-256 of those bytes must equal attestation.entry_hash.value.
  3. attestation.prev_entry_hash.value must equal the previous event's
     entry_hash (absent on the genesis entry).
  4. attestation.sequence must increase by exactly 1 within the chain.
  5. (If key available) the ECDSA signature must verify over the same
     canonical bytes.

Exit code 0 = chain intact, 1 = verification failure.
"""

import base64
import copy
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).parent
PUBKEY = HERE / "demo_signing_key_public.pem"


def canonical_bytes(event: dict) -> bytes:
    e = copy.deepcopy(event)
    e.pop("unmapped", None)  # transport for the raw signature bytes, not signed content
    att = e.get("attestation", {})
    att.pop("entry_hash", None)
    att.pop("signature", None)
    return json.dumps(e, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def load_verifier():
    if not PUBKEY.exists():
        return None
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec
    except ImportError:
        return None
    key = serialization.load_pem_public_key(PUBKEY.read_bytes())

    def verify(payload: bytes, sig_der: bytes) -> bool:
        try:
            key.verify(sig_der, payload, ec.ECDSA(hashes.SHA256()))
            return True
        except Exception:
            return False

    return verify


def main(path: str) -> int:
    events = json.loads(Path(path).read_text())
    verify_sig = load_verifier()
    print(f"OCSF attestation chain verify — {Path(path).name}")
    print(f"  Events: {len(events)}   Signature check: {'ON' if verify_sig else 'off (no key / no cryptography pkg)'}")
    print()

    prev_hash = None
    prev_seq = 0
    for i, event in enumerate(events, start=1):
        att = event.get("attestation")
        if not att:
            print(f"  Entry #{i}: FAIL — no attestation object")
            return 1
        op = event.get("api", {}).get("operation", "?")
        status = event.get("status", "?")
        payload = canonical_bytes(event)
        computed = hashlib.sha256(payload).hexdigest()
        claimed = att.get("entry_hash", {}).get("value")

        if computed != claimed:
            print(f"  Entry #{i}: {op}  [{status}]")
            print(f"            CHAIN BROKEN ✗ — record does not match its hash")
            print(f"            claimed entry_hash:  {claimed[:16]}…")
            print(f"            computed from record: {computed[:16]}…")
            print(f"            This record was ALTERED after it was written.")
            return 1

        claimed_prev = att.get("prev_entry_hash", {}).get("value")
        if i == 1:
            if claimed_prev is not None:
                print(f"  Entry #{i}: FAIL — genesis entry must not have prev_entry_hash")
                return 1
        elif claimed_prev != prev_hash:
            print(f"  Entry #{i}: CHAIN BROKEN ✗ — prev_entry_hash does not match entry #{i-1}")
            return 1

        seq = att.get("sequence")
        if seq is not None:
            if seq != prev_seq + 1:
                print(f"  Entry #{i}: CHAIN BROKEN ✗ — sequence gap ({prev_seq} -> {seq}): records missing?")
                return 1
            prev_seq = seq

        sig_note = ""
        if verify_sig:
            sig_b64 = event.get("unmapped", {}).get("signature_b64")
            if not sig_b64 or not verify_sig(payload, base64.b64decode(sig_b64)):
                print(f"  Entry #{i}: SIGNATURE INVALID ✗ — not produced by the holder of the signing key")
                return 1
            sig_note = "  sig ✓"

        print(f"  Entry #{i}: {op}  [{status}]  hash ✓  link ✓{sig_note}")
        prev_hash = computed

    print()
    print(f"  Result: CHAIN INTACT ✓   {len(events)}/{len(events)} entries verified")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(sys.argv[1]))

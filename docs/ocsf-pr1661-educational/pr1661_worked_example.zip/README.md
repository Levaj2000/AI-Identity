# Worked example for ocsf/ocsf-schema#1661 — start here

This zip accompanies the `attestation` object proposed in PR #1661.
It lets you verify a tamper-evident event chain yourself, offline, in
about two minutes. No setup beyond Python 3.9+ (already on macOS/Linux).

## What's in here

| File | What it is |
|---|---|
| `README.md` | This file |
| `ocsf_example_chain.json` | **The main exhibit.** Three OCSF `API Activity` events from an AI support agent — read ticket, look up order, attempt a refund that is DENIED by policy. Each event carries the proposed `attestation` object with real, recomputable hashes and a real signature. |
| `ocsf_example_chain_TAMPERED.json` | The same three events after an "attacker" edited the stored log: the denied refund now claims `"status": "Success"`. The hashes were left untouched — exactly what a real tamperer is stuck with. |
| `verify_ocsf_example.py` | A ~100-line verifier (Python standard library only for the chain math). Read it — it IS the specification of how verification works. |
| `demo_signing_key_public.pem` | Public half of the throwaway key that signed the events. The private key was generated for this demo and discarded. |
| `sample_production_log_sanitized.json` | Bonus: a sanitized window of a real production agent-gateway log showing the same pattern live, including a real policy deny and TWO parallel chains per record (global + org-level). Identifiers pseudonymized — see its `_note` field. Not recomputable; for schema-shape reference only. |

## Run it yourself (2 minutes, no installs)

These are local commands — no server, no API, no network. The script
reads the JSON files in this folder and redoes the math on your machine;
that independence is the point of the attestation design.

Open a terminal in this folder (macOS/Linux: `python3` is preinstalled;
Windows: use `py` instead of `python3`) and run the verifier on the
intact chain:

```
$ python3 verify_ocsf_example.py ocsf_example_chain.json
```

You should see every record pass all three checks:

```
Entry #1: POST /agent/tools/read_ticket   [Success]  hash ✓  link ✓  sig ✓
Entry #2: POST /agent/tools/lookup_order  [Success]  hash ✓  link ✓  sig ✓
Entry #3: POST /agent/tools/issue_refund  [Failure]  hash ✓  link ✓  sig ✓
Result: CHAIN INTACT ✓   3/3 entries verified
```

(`hash ✓` = the record still matches its own `entry_hash` · `link ✓` =
its `prev_entry_hash` matches the previous record · `sig ✓` = the
signature verifies against the included public key. Signature checking
needs the `cryptography` package — without it the script says so and
still verifies the hash chain with nothing installed.)

Now run the same command on the tampered copy — where the policy-denied
refund was edited to claim it succeeded:

```
$ python3 verify_ocsf_example.py ocsf_example_chain_TAMPERED.json
```

The edited record is caught:

```
Entry #3: POST /agent/tools/issue_refund  [Success]
          CHAIN BROKEN ✗ — record does not match its hash
```

## What you just proved

- **Tamper-evidence** (`entry_hash` + `prev_entry_hash` + `chain_uid`):
  each event stores a digest of its own canonical bytes and the digest of
  the previous event. Changing or deleting any stored record breaks the
  math for every record after it. Same primitive that makes git history
  trustworthy.
- **Non-repudiation** (`signature`): the same canonical bytes are signed,
  so the record is bound to whoever holds the signing key — the producer
  can't later deny having written it.

Open `ocsf_example_chain.json` alongside the verifier output. The only
schema addition is the `attestation` object on each event; everything
else is ordinary OCSF.

## The one rule that makes it work (canonicalization)

Producer and verifier must hash *identical bytes*. The rule demonstrated
here:

- **Included:** every attribute of the event, plus the chain coordinates
  (`chain_uid`, `prev_entry_hash`, `sequence`).
- **Excluded:** `attestation.entry_hash` and `attestation.signature` —
  an output can't be part of its own input.
- **Declared, not mandated:** the serialization scheme is named in-band
  via `digital_signature.serialization_id` (JCS here; JWS/COSE/DSSE also
  enumerated — added in PR #1662), so verifiers know which rule to apply.

## Questions / discussion

On the PR thread: https://github.com/ocsf/ocsf-schema/pull/1661
